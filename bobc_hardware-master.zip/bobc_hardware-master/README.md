#Various hardware projects

* RepRap Control Panel

  A Control Panel for RepRap printers, based on Makerbot Control Panel.

* LPC1343 CPU Module

  A Mini Module for NXP LPC1343 based on MicropendousX-1343.

