# MotionBoard
FirePick Delta/Ramps compatible motion controller running Smoothie
