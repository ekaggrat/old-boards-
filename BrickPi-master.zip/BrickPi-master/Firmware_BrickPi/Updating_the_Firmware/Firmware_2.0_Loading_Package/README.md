Updating the Firmware for the BrickPi

This directory contains the batch files and firmware for updating the BrickPi Firmware.

In this version we use the Raspberry Pi to reprogram the BrickPi firmware using either an Arduino or an AVR Programmer.