#! /bin/bash
id=$(pidof python)
kill $id