for i in range(10):
	print "hello \n"

	
