# BrickPi Python Sensor Examples

This repository contains examples for using the BrickPi in Python.

## Sensor Examples: 
Before starting with the examples, please copy "BrickPi.py" from the drivers folder into the examples folder.

BrickPi is a Raspberry Pi Board that connects LEGO MINDSTORMS motors and sensors to the Raspberry Pi.

[More information on hardware, firmware, and software can be found here](http://www.dexterindustries.com/BrickPi)
