#!/usr/bin/env python
###############################################################################################################                                                          
# Program Name: Browser_Client_Coder.html                                     
# ================================     
# This code is for controlling a robot by a web browser using web sockets                            
# http://www.dexterindustries.com/                                                                
# History
# ------------------------------------------------
# Author     Comments
# Joshwa     Initial Authoring
#                                                                  
# These files have been made available online through a Creative Commons Attribution-ShareAlike 3.0  license.
# (http://creativecommons.org/licenses/by-sa/3.0/)           
#
###############################################################################################################

# CONNECTIONS-
# 	Left Motor  - Port A
# 	Right Motor - Port D
#
# PREREQUISITES
#	Tornado Web Server for Python
#
# TROUBLESHOOTING:
#	Don't use Ctrl+Z to stop the program, use Ctrl+c.
#	If you use Ctrl+Z, it will not close the socket and you won't be able to run the program the next time.
#	If you get the following error:
#		"socket.error: [Errno 98] Address already in use "
#	Run this on the terminal:
#		"sudo netstat -ap |grep :9093"
#	Note down the PID of the process running it
#	And kill that process using:
#		"kill pid"
#	If it does not work use:
#		"kill -9 pid"
#	If the error does not go away, try changin the port number '9093' both in the client and server code

from BrickPi import *   #import BrickPi.py file to use BrickPi operations
import threading
import tornado.ioloop
import tornado.web
import tornado.websocket
import tornado.template
import camera_streamer

cameraStreamer = None
c=0
global left_power
global right_power
right_power = 0
left_power = 0

#Initialize TOrnado to use 'GET' and load index.html
class MainHandler(tornado.web.RequestHandler):
    def get(self):
        loader = tornado.template.Loader(".")
        self.write(loader.load("index.html").generate())

#Code for handling the data sent from the webpage
class WSHandler(tornado.websocket.WebSocketHandler):
    def open(self):
        print 'connection opened...'
        cameraStreamer.startStreaming()
    def check_origin(self,origin):
        return True
    def on_message(self, message):      # receives the data from the webpage and is stored in the variable message
        global c
        global left_power
        global right_power
        cameraStreamer.update
        print 'received:', message        # prints the revived from the webpage 
        if message == "u":                # checks for the received data and assigns different values to c which controls the movement of robot.
            c = "8";
        if message == "d":
            c = "2"
        if message == "l":
            c = "6"
        if message == "r":
            c = "4"
        if message == "b":
            c = "5"
        if message == "lu":
            c = "7"
        if message == "ru":
            c = "9"
        if message == "ld":
            c = "1"
        if message == "rd":
            c = "3"
        print c
        if c == '8' :
            print "Running Forward"
            # first check which side has higher power and set it to the lowest setting before increasing it
            if right_power > left_power:
                right_power = left_power
            if left_power > right_power:
                left_power = right_power
            right_power = right_power + 50
            if right_power > 255:
                right_power = 255
            left_power = right_power
            BrickPi.MotorSpeed[PORT_B] = left_power  #Set the speed of MotorB (-255 to 255)
            BrickPi.MotorSpeed[PORT_D] = right_power  #Set the speed of MotorD (-255 to 255)
        elif c == '2' :
            print "Running Reverse"
            # first check which side has lower power and set it to the lowest setting before increasing it
            if right_power < left_power:
                right_power = left_power
            if left_power < right_power:
                left_power = right_power
            right_power = right_power - 50
            if right_power < -255:
                right_power = -255
            left_power = right_power
            BrickPi.MotorSpeed[PORT_B] = left_power  
            BrickPi.MotorSpeed[PORT_D] = right_power  
        elif c == '4' :
            print "Turning Left"
            left_power = left_power + 100
            right_power = 0
            if left_power > 255:
                left_power = 255
            BrickPi.MotorSpeed[PORT_B] = left_power
            BrickPi.MotorSpeed[PORT_D] = right_power
        elif c == '7' :
            print "Turning diagonal Left"
            if right_power > 200:
                right_power = 100
            right_power = right_power + 50
            left_power = right_power / 2
            if right_power > 255:
                right_power = 255
            BrickPi.MotorSpeed[PORT_B] = left_power
            BrickPi.MotorSpeed[PORT_D] = right_power
        elif c == '6' :
            print "Turning Right"
            right_power = right_power + 100
            left_power = 0
            if right_power > 255:
                right_power = 255
            BrickPi.MotorSpeed[PORT_B] = left_power  
            BrickPi.MotorSpeed[PORT_D] = right_power  
        elif c == '9' :
            print "Turning diagonal Right"
            if left_power > 200:
                left_power = 100
            left_power = left_power + 50
            right_power = left_power / 2
            if left_power > 255:
                left_power = 255
            BrickPi.MotorSpeed[PORT_B] = left_power
            BrickPi.MotorSpeed[PORT_D] = right_power
        elif c == '5' :
            print "Stopped"
            right_power = 0
            left_power = 0
            BrickPi.MotorSpeed[PORT_B] = left_power
            BrickPi.MotorSpeed[PORT_D] = right_power
        BrickPiUpdateValues();                # BrickPi updates the values for the motors
        print "Values Updated"
    def on_close(self):
        cameraStreamer.stopStreaming()
        print 'connection closed...'

application = tornado.web.Application([
    (r'/ws', WSHandler),
    (r'/', MainHandler),
    (r"/(.*)", tornado.web.StaticFileHandler, {"path": "./resources"}),
])

class myThread (threading.Thread):
    def __init__(self, threadID, name, counter):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.counter = counter
    def run(self):
        print "Ready"
        while running:
            BrickPiUpdateValues()       # Ask BrickPi to update values for sensors/motors
            time.sleep(.2)              # sleep for 200 ms
        cameraStreamer.stopStreaming()

if __name__ == "__main__":
    BrickPiSetup()  						# setup the serial port for communication
    BrickPi.MotorEnable[PORT_B] = 1 		#Enable the Motor B
    BrickPi.MotorEnable[PORT_D] = 1 		#Enable the Motor D
    BrickPiSetupSensors()   				#Send the properties of sensors to BrickPi
    running = True
    thread1 = myThread(1, "Thread-1", 1)
    thread1.setDaemon(True)
    thread1.start()  
    application.listen(9093)          	#starts the websockets connection
    
    cameraStreamer = camera_streamer.CameraStreamer()
    
    tornado.ioloop.IOLoop.instance().start()
  

