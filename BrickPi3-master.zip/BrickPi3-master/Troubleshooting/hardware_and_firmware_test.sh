#! /bin/bash
echo ""
echo "Checking for hardware, and checking hardware and firmware version."
echo "=================================================================="
sudo python /home/pi/Dexter/BrickPi3/Software/Python/Examples/Read_Info.py
