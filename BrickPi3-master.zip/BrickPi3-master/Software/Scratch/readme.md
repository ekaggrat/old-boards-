Scratch control is achieved with the use of broadcast blocks

This image is a reference guide:

![IBrickPi3 Scratch Reference Guide](BrickPi3_Scratch_Commands.png)
