This project was derived from Arduino 2560 which can be found here:

http://arduino.cc/en/Main/ArduinoBoardMega2560